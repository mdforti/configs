The comment-stripped versions are the ones sent to Bram Moolenaar to be
bundled in Vim releases.
They were not included in this repository until version 1.37
